package com.example.newiptv.ui.series

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.newiptv.R
import com.example.newiptv.ui.seriesinfo.SeriesInfoScreen

class SeriesScreen : AppCompatActivity() {

    private lateinit var categoryListView: ListView
    private lateinit var seriesRecyclerView: RecyclerView
    private lateinit var seriesAdapter: SeriesAdapter
    private lateinit var loadingText: TextView
    private lateinit var errorText: TextView
    
    private var selectedCategoryIndex = 0
    private var selectedSeriesIndex = 0
    private var isInCategoryPanel = true
    
    // Sample data - will be replaced with API calls
    private val categories = listOf(
        "Action", "Comedy", "Drama", "Horror", "Sci-Fi", "Thriller", "Romance", "Documentary", "Animation"
    )
    
    private val seriesData = mapOf(
        "Action" to listOf("Breaking Bad", "The Walking Dead", "Game of Thrones", "Stranger Things"),
        "Comedy" to listOf("Friends", "The Office", "Parks and Recreation", "Brooklyn Nine-Nine"),
        "Drama" to listOf("The Crown", "Mad Men", "Better Call Saul", "Ozark"),
        "Horror" to listOf("American Horror Story", "The Haunting", "Penny Dreadful", "The Exorcist"),
        "Sci-Fi" to listOf("Black Mirror", "Westworld", "The Expanse", "Altered Carbon"),
        "Thriller" to listOf("Mindhunter", "True Detective", "Fargo", "The Sinner"),
        "Romance" to listOf("Outlander", "Bridgerton", "Virgin River", "Sweet Magnolias"),
        "Documentary" to listOf("Planet Earth", "Cosmos", "Making a Murderer", "Tiger King"),
        "Animation" to listOf("Rick and Morty", "BoJack Horseman", "Avatar", "The Simpsons")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series_screen)
        
        initializeViews()
        setupCategoryList()
        setupSeriesGrid()
        setupTVRemoteNavigation()
        loadSeriesForCategory(selectedCategoryIndex)
    }

    private fun initializeViews() {
        categoryListView = findViewById(R.id.categoryListView)
        seriesRecyclerView = findViewById(R.id.seriesRecyclerView)
        loadingText = findViewById(R.id.loadingText)
        errorText = findViewById(R.id.errorText)
    }

    private fun setupCategoryList() {
        val categoryAdapter = CategoryAdapter(this, categories)
        categoryListView.adapter = categoryAdapter
        
        // Set focus change listener for categories
        categoryListView.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                android.util.Log.d("SeriesScreen", "Category list got FOCUS")
            }
        }
        
        categoryListView.setOnItemClickListener { _, _, position, _ ->
            selectedCategoryIndex = position
            loadSeriesForCategory(position)
            updateCategorySelection()
        }
    }

    private fun setupSeriesGrid() {
        seriesAdapter = SeriesAdapter { series ->
            // Launch Series Info screen instead of video player
            val intent = Intent(this, SeriesInfoScreen::class.java)
            intent.putExtra("series_name", series)
            intent.putExtra("series_category", categories[selectedCategoryIndex])
            startActivity(intent)
        }
        
        seriesRecyclerView.apply {
            layoutManager = GridLayoutManager(this@SeriesScreen, 3)
            adapter = seriesAdapter
            
            // Set focus change listener for series grid
            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    android.util.Log.d("SeriesScreen", "Series grid got FOCUS")
                }
            }
        }
    }

    private fun setupTVRemoteNavigation() {
        // Set initial focus to category panel
        categoryListView.requestFocus()
        
        val rootView = findViewById<View>(android.R.id.content)
        rootView.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        // Let Android TV handle natural focus navigation
                        // Only switch panels when crossing the boundary
                        if (isInCategoryPanel) {
                            // If we're in category panel and press left, move to series panel
                            isInCategoryPanel = false
                            seriesRecyclerView.requestFocus()
                            updateFocus()
                            android.util.Log.d("SeriesScreen", "Moved to Series Panel")
                        }
                        return@setOnKeyListener true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        // Let Android TV handle natural focus navigation
                        // Only switch panels when crossing the boundary
                        if (!isInCategoryPanel) {
                            // If we're in series panel and press right, move to category panel
                            isInCategoryPanel = true
                            categoryListView.requestFocus()
                            updateFocus()
                            android.util.Log.d("SeriesScreen", "Moved to Category Panel")
                        }
                        return@setOnKeyListener true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        // Let Android TV handle natural up/down navigation within each panel
                        return@setOnKeyListener false // Let system handle it
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        // Let Android TV handle natural up/down navigation within each panel
                        return@setOnKeyListener false // Let system handle it
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        if (isInCategoryPanel) {
                            categoryListView.performItemClick(
                                categoryListView.getChildAt(selectedCategoryIndex),
                                selectedCategoryIndex,
                                categoryListView.getItemIdAtPosition(selectedCategoryIndex)
                            )
                        } else {
                            // Handle series selection - launch Series Info screen
                            val series = seriesAdapter.getSeriesAt(selectedSeriesIndex)
                            if (series != null) {
                                val intent = Intent(this, SeriesInfoScreen::class.java)
                                intent.putExtra("series_name", series)
                                intent.putExtra("series_category", categories[selectedCategoryIndex])
                                startActivity(intent)
                            }
                        }
                        return@setOnKeyListener true
                    }
                    KeyEvent.KEYCODE_BACK -> {
                        finish()
                        return@setOnKeyListener true
                    }
                }
            }
            false
        }
    }

    private fun navigateCategoryUp() {
        if (selectedCategoryIndex > 0) {
            selectedCategoryIndex--
            categoryListView.setSelection(selectedCategoryIndex)
            updateCategoryVisualSelection()
        }
    }

    private fun navigateCategoryDown() {
        if (selectedCategoryIndex < categories.size - 1) {
            selectedCategoryIndex++
            categoryListView.setSelection(selectedCategoryIndex)
            updateCategoryVisualSelection()
        }
    }

    private fun navigateSeriesUp() {
        if (selectedSeriesIndex >= 3) {
            selectedSeriesIndex -= 3
            seriesAdapter.setSelectedIndex(selectedSeriesIndex)
        }
    }

    private fun navigateSeriesDown() {
        val currentSeries = seriesAdapter.getSeriesList()
        if (selectedSeriesIndex < currentSeries.size - 3) {
            selectedSeriesIndex += 3
            seriesAdapter.setSelectedIndex(selectedSeriesIndex)
        }
    }



    private fun updateCategorySelection() {
        categoryListView.setSelection(selectedCategoryIndex)
        updateFocus()
        updateCategoryVisualSelection()
    }

    private fun updateSeriesSelection() {
        seriesAdapter.setSelectedIndex(selectedSeriesIndex)
        updateFocus()
    }

    private fun updateFocus() {
        if (isInCategoryPanel) {
            categoryListView.requestFocus()
        } else {
            seriesRecyclerView.requestFocus()
        }
    }

    private fun loadSeriesForCategory(categoryIndex: Int) {
        val category = categories[categoryIndex]
        val series = seriesData[category] ?: emptyList()
        
        loadingText.visibility = View.GONE
        errorText.visibility = View.GONE
        
        if (series.isEmpty()) {
            errorText.text = "No series found in $category"
            errorText.visibility = View.VISIBLE
        } else {
            seriesAdapter.updateSeries(series)
            selectedSeriesIndex = 0
            updateSeriesSelection()
        }
    }

    private fun updateCategoryVisualSelection() {
        // Update visual selection in category list with enhanced feedback
        for (i in 0 until categoryListView.count) {
            val view = categoryListView.getChildAt(i)
            if (view != null) {
                val card = view.findViewById<CardView>(R.id.categoryCard)
                if (i == selectedCategoryIndex) {
                    // Enhanced selected state with hover animation
                    card.elevation = 24f
                    card.setCardBackgroundColor(ContextCompat.getColor(this, R.color.selection_primary))
                    card.alpha = 1.0f
                    card.scaleX = 1.1f  // Increased scale for better hover effect
                    card.scaleY = 1.1f
                    
                    // Add rotation animation for flip effect
                    card.animate()
                        .rotationY(5f)
                        .setDuration(200)
                        .start()
                } else {
                    // Normal state
                    card.elevation = 8f
                    card.setCardBackgroundColor(ContextCompat.getColor(this, R.color.card_background))
                    card.alpha = 0.8f
                    card.scaleX = 1.0f
                    card.scaleY = 1.0f
                    
                    // Reset rotation
                    card.animate()
                        .rotationY(0f)
                        .setDuration(200)
                        .start()
                }
            }
        }
    }
}
