package com.example.newiptv.ui.seriesinfo

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.newiptv.R
import com.example.newiptv.player.VideoPlayerActivity
import androidx.recyclerview.widget.GridLayoutManager

class SeriesInfoScreen : AppCompatActivity() {

    private lateinit var seriesTitleView: TextView
    private lateinit var seriesCategoryView: TextView
    private lateinit var seriesDescriptionView: TextView
    private lateinit var seasonsListView: ListView
    private lateinit var episodesRecyclerView: RecyclerView
    private lateinit var episodesAdapter: EpisodesAdapter
    private lateinit var loadingText: TextView
    private lateinit var errorText: TextView
    
    private var selectedSeasonIndex = 0
    private var selectedEpisodeIndex = 0
    private var isInSeasonsPanel = true
    
    private lateinit var seriesName: String
    private lateinit var seriesCategory: String
    
    // Sample data - will be replaced with API calls
    private val seasons = listOf("Season 1", "Season 2", "Season 3", "Season 4", "Season 5")
    
    private val episodesData = mapOf(
        "Season 1" to listOf(
            "Episode 1: Pilot",
            "Episode 2: The Beginning",
            "Episode 3: The Plot Thickens",
            "Episode 4: Rising Action",
            "Episode 5: The Climax",
            "Episode 6: Resolution"
        ),
        "Season 2" to listOf(
            "Episode 1: New Beginnings",
            "Episode 2: The Return",
            "Episode 3: Complications",
            "Episode 4: The Twist",
            "Episode 5: The Fallout",
            "Episode 6: The Aftermath"
        ),
        "Season 3" to listOf(
            "Episode 1: The Reckoning",
            "Episode 2: New Alliances",
            "Episode 3: Betrayal",
            "Episode 4: The Hunt",
            "Episode 5: The Trap",
            "Episode 6: The Escape"
        ),
        "Season 4" to listOf(
            "Episode 1: The Final Chapter",
            "Episode 2: Last Stand",
            "Episode 3: The End Game",
            "Episode 4: Victory",
            "Episode 5: The Aftermath",
            "Episode 6: New Horizons"
        ),
        "Season 5" to listOf(
            "Episode 1: The Legacy",
            "Episode 2: The Future",
            "Episode 3: The Promise",
            "Episode 4: The Hope",
            "Episode 5: The Dream",
            "Episode 6: The Beginning"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series_info_screen)
        
        // Get series data from intent
        seriesName = intent.getStringExtra("series_name") ?: "Unknown Series"
        seriesCategory = intent.getStringExtra("series_category") ?: "Unknown Category"
        
        initializeViews()
        setupSeriesInfo()
        setupSeasonsList()
        setupEpisodesGrid()
        setupTVRemoteNavigation()
        loadEpisodesForSeason(selectedSeasonIndex)
    }

    private fun initializeViews() {
        seriesTitleView = findViewById(R.id.seriesTitleView)
        seriesCategoryView = findViewById(R.id.seriesCategoryView)
        seriesDescriptionView = findViewById(R.id.seriesDescriptionView)
        seasonsListView = findViewById(R.id.seasonsListView)
        episodesRecyclerView = findViewById(R.id.episodesRecyclerView)
        loadingText = findViewById(R.id.loadingText)
        errorText = findViewById(R.id.errorText)
    }

    private fun setupSeriesInfo() {
        seriesTitleView.text = seriesName
        seriesCategoryView.text = seriesCategory
        seriesDescriptionView.text = "A compelling $seriesCategory series that follows the journey of its characters through various challenges and adventures. This series has captivated audiences worldwide with its unique storytelling and memorable characters."
    }

    private fun setupSeasonsList() {
        val seasonsAdapter = SeasonsAdapter(this, seasons)
        seasonsListView.adapter = seasonsAdapter
        
        // Set focus change listener for seasons
        seasonsListView.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                android.util.Log.d("SeriesInfoScreen", "Seasons list got FOCUS")
            }
        }
        
        seasonsListView.setOnItemClickListener { _, _, position, _ ->
            selectedSeasonIndex = position
            loadEpisodesForSeason(position)
            updateSeasonSelection()
        }
    }

    private fun setupEpisodesGrid() {
        episodesAdapter = EpisodesAdapter { episode ->
            // Launch video player for the selected episode
            val intent = Intent(this, VideoPlayerActivity::class.java)
            intent.putExtra("video_url", "https://example.com/video.mp4") // Default video URL
            intent.putExtra("episode_title", episode)
            startActivity(intent)
        }
        
        episodesRecyclerView.apply {
            layoutManager = GridLayoutManager(this@SeriesInfoScreen, 3)
            adapter = episodesAdapter
            
            // Set focus change listener for episodes grid
            setOnFocusChangeListener { _, hasFocus ->
                if (hasFocus) {
                    android.util.Log.d("SeriesInfoScreen", "Episodes grid got FOCUS")
                }
            }
        }
    }

    private fun setupTVRemoteNavigation() {
        // Set initial focus to seasons panel
        seasonsListView.requestFocus()
        
        val rootView = findViewById<View>(android.R.id.content)
        rootView.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        // Let Android TV handle natural focus navigation
                        // Only switch panels when crossing the boundary
                        if (isInSeasonsPanel) {
                            // If we're in seasons panel and press left, move to episodes panel
                            isInSeasonsPanel = false
                            episodesRecyclerView.requestFocus()
                            updateFocus()
                            android.util.Log.d("SeriesInfoScreen", "Moved to Episodes Panel")
                        }
                        return@setOnKeyListener true
                    }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        // Let Android TV handle natural focus navigation
                        // Only switch panels when crossing the boundary
                        if (!isInSeasonsPanel) {
                            // If we're in episodes panel and press right, move to seasons panel
                            isInSeasonsPanel = true
                            seasonsListView.requestFocus()
                            updateFocus()
                            android.util.Log.d("SeriesInfoScreen", "Moved to Seasons Panel")
                        }
                        return@setOnKeyListener true
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        // Let Android TV handle natural up/down navigation within each panel
                        return@setOnKeyListener false // Let system handle it
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        // Let Android TV handle natural up/down navigation within each panel
                        return@setOnKeyListener false // Let system handle it
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        if (isInSeasonsPanel) {
                            seasonsListView.performItemClick(
                                seasonsListView.getChildAt(selectedSeasonIndex),
                                selectedSeasonIndex,
                                seasonsListView.getItemIdAtPosition(selectedSeasonIndex)
                            )
                        } else {
                            // Handle episode selection - launch video player
                            val episode = episodesAdapter.getEpisodeAt(selectedEpisodeIndex)
                            if (episode != null) {
                                val intent = Intent(this, VideoPlayerActivity::class.java)
                                intent.putExtra("video_url", "https://example.com/video.mp4")
                                intent.putExtra("episode_title", episode)
                                startActivity(intent)
                            }
                        }
                        return@setOnKeyListener true
                    }
                    KeyEvent.KEYCODE_BACK -> {
                        finish()
                        return@setOnKeyListener true
                    }
                }
            }
            false
        }
    }

    private fun navigateSeasonUp() {
        if (selectedSeasonIndex > 0) {
            val newIndex = selectedSeasonIndex - 1
            updateSeasonHover(newIndex)
        }
    }

    private fun navigateSeasonDown() {
        if (selectedSeasonIndex < seasons.size - 1) {
            val newIndex = selectedSeasonIndex + 1
            updateSeasonHover(newIndex)
        }
    }

    private fun navigateEpisodeUp() {
        if (selectedEpisodeIndex > 0) {
            val newIndex = selectedEpisodeIndex - 1
            updateEpisodeHover(newIndex)
        }
    }

    private fun navigateEpisodeDown() {
        val currentEpisodes = episodesAdapter.getEpisodesList()
        if (selectedEpisodeIndex < currentEpisodes.size - 1) {
            val newIndex = selectedEpisodeIndex + 1
            updateEpisodeHover(newIndex)
        }
    }

    private fun updateSeasonHover(newIndex: Int) {
        if (newIndex != selectedSeasonIndex && newIndex in seasons.indices) {
            selectedSeasonIndex = newIndex
            updateSeasonSelection()
        }
    }

    private fun updateEpisodeHover(newIndex: Int) {
        val currentEpisodes = episodesAdapter.getEpisodesList()
        if (newIndex != selectedEpisodeIndex && newIndex in currentEpisodes.indices) {
            selectedEpisodeIndex = newIndex
            updateEpisodeSelection()
        }
    }

    private fun updateSeasonSelection() {
        seasonsListView.setSelection(selectedSeasonIndex)
        updateFocus()
        updateSeasonVisualSelection()
    }

    private fun updateEpisodeSelection() {
        episodesAdapter.setSelectedIndex(selectedEpisodeIndex)
        updateFocus()
    }

    private fun updateFocus() {
        if (isInSeasonsPanel) {
            seasonsListView.requestFocus()
        } else {
            episodesRecyclerView.requestFocus()
        }
    }

    private fun loadEpisodesForSeason(seasonIndex: Int) {
        val season = seasons[seasonIndex]
        val episodes = episodesData[season] ?: emptyList()
        
        loadingText.visibility = View.GONE
        errorText.visibility = View.GONE
        
        if (episodes.isEmpty()) {
            errorText.text = "No episodes found in $season"
            errorText.visibility = View.VISIBLE
        } else {
            episodesAdapter.updateEpisodes(episodes)
            selectedEpisodeIndex = 0
            updateEpisodeSelection()
        }
    }

    private fun updateSeasonVisualSelection() {
        // Update visual selection in seasons list with enhanced feedback
        for (i in 0 until seasonsListView.count) {
            val view = seasonsListView.getChildAt(i)
            if (view != null) {
                val card = view.findViewById<CardView>(R.id.seasonCard)
                if (i == selectedSeasonIndex) {
                    // Enhanced selected state with hover animation
                    card.elevation = 24f
                    card.setCardBackgroundColor(ContextCompat.getColor(this, R.color.selection_primary))
                    card.alpha = 1.0f
                    card.scaleX = 1.1f  // Increased scale for better hover effect
                    card.scaleY = 1.1f
                    
                    // Add rotation animation for flip effect
                    card.animate()
                        .rotationY(5f)
                        .setDuration(200)
                        .start()
                } else {
                    // Normal state
                    card.elevation = 8f
                    card.setCardBackgroundColor(ContextCompat.getColor(this, R.color.card_background))
                    card.alpha = 0.8f
                    card.scaleX = 1.0f
                    card.scaleY = 1.0f
                    
                    // Reset rotation
                    card.animate()
                        .rotationY(0f)
                        .setDuration(200)
                        .start()
                }
            }
        }
    }
}
